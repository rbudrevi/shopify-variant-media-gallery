# Decal Calculator & Variant Media Gallery
### Developer Handoff — Installation Guide

---

## Overview

This package adds two features to a Shopify Dawn theme product page:

1. **Decal Calculator** — A modal quantity estimator. Customers enter their window dimensions, choose a spacing tier, and get a live SVG preview showing how many decal sheets they need.
2. **Variant Media Gallery** — Filters the product image gallery to show only the images associated with the currently selected variant.

---

## File List

| File | Type | Action |
|---|---|---|
| `decal-calculator.liquid` | Snippet | **Add new** |
| `decal-calculator-modal.liquid` | Snippet | **Add new** |
| `decal-calculator-trigger.liquid` | Snippet | **Add new** |
| `main-product.liquid` | Section | **Replace existing** |
| `product-media-gallery.liquid` | Snippet | **Replace existing** |
| `media-gallery.js` | Asset | **Replace existing** |
| `variant-media-gallery.js` | Asset | **Add new** |

> **Theme compatibility:** Dawn 14+. If you are on an older Dawn version, compare `main-product.liquid` and `product-media-gallery.liquid` against your existing files before replacing — the changes are additive and listed explicitly in the "What Was Modified" section below.

---

## Step-by-Step Install

### 1. Back up first
In the Shopify admin, go to **Online Store → Themes**, click the **•••** menu on your live theme, and duplicate it. Work on the duplicate.

---

### 2. Add the three new snippets

In the theme editor (**Online Store → Themes → Edit code**):

- Navigate to the **Snippets** folder
- Click **Add a new snippet** for each of the following, name it exactly as shown, and paste in the file contents:
  - `decal-calculator`
  - `decal-calculator-modal`
  - `decal-calculator-trigger`

---

### 3. Replace `main-product.liquid`

- In the theme editor, open **Sections → main-product.liquid**
- Replace the entire file with the provided `main-product.liquid`

**What was added vs stock Dawn:**

| Location | Change |
|---|---|
| Line 392 (inside `quantity_selector` block) | `{% render 'decal-calculator-trigger' %}` — renders the "Estimate how many you need" link |
| Lines 722–736 (after media block) | `window.ProductData` script block — exposes variant IDs and `pack_decal_count` metafield to JS |
| Line 740 | `<script src="{{ 'variant-media-gallery.js' \| asset_url }}" defer="defer"></script>` — loads the gallery filter script |
| Line 763 (bottom of section, before `</product-info>`) | `{% render 'decal-calculator-modal', product: product %}` — renders the modal |
| Lines 773–799 | New `dynamic_collapsible_tab` block type in the schema |

---

### 4. Replace `product-media-gallery.liquid`

- In the theme editor, open **Snippets → product-media-gallery.liquid**
- Replace the entire file with the provided `product-media-gallery.liquid`

**What was added vs stock Dawn:**

| Location | Change |
|---|---|
| Lines 54–67 (inside `<media-gallery>`, before `GalleryStatus`) | `<script type="application/json" data-variant-associated-urls>` block — outputs a JSON map of `variantId → [imageUrls]` from the `custom.associated_media` metafield |

---

### 5. Replace `media-gallery.js`

- In the theme editor, open **Assets → media-gallery.js**
- Replace the entire file with the provided `media-gallery.js`

> This file is minimally changed from Dawn stock. If you have other customizations in your existing `media-gallery.js`, do a diff before replacing.

---

### 6. Add `variant-media-gallery.js`

- In the theme editor, navigate to **Assets**
- Click **Add a new asset → Create a blank file**
- Name it `variant-media-gallery.js`
- Paste in the contents of the provided `variant-media-gallery.js`

---

### 7. Create the required Metafields

Go to **Settings → Custom data** in the Shopify admin.

#### Product Metafields (Settings → Custom data → Products)

| Namespace & Key | Type | Purpose |
|---|---|---|
| `custom.average_size` | Decimal | Decal size in inches (e.g. `1.25`) |
| `custom.decal_count` | Integer | Decals per sheet (e.g. `10`) |
| `custom.decal_shape` | Single line text | Fallback shape: `diamond`, `circle`, or `square` |
| `custom.silhouette_path` | Single line text | SVG path data string. Pipe-separate (`\|`) for alternating shapes. Leave blank to use `decal_shape` fallback. |
| `custom.display_style` | Single line text | Reserved for future use. Set to `grid` or leave blank. |

#### Variant Metafields (Settings → Custom data → Product variants)

| Namespace & Key | Type | Purpose |
|---|---|---|
| `custom.associated_media` | File — List | Image files to show when this variant is selected in the gallery |
| `custom.pack_decal_count` | Integer | Number of decals in this specific variant's pack (used in `window.ProductData` for future JS use) |

---

### 8. Populate metafields on your product

- Open the product in the Shopify admin
- Scroll to the **Metafields** section at the bottom
- Fill in `average_size`, `decal_count`, and either `silhouette_path` or `decal_shape`
- For each variant, open the variant detail page and attach images to `associated_media`

---

### 9. Verify in the theme editor

- Open the product page in the theme editor (or preview)
- The **"Estimate how many you need"** link should appear near the quantity input
- Clicking it opens the modal with the calculator
- Selecting a variant should filter the gallery to show only that variant's associated images

---

## How It Works — Architecture Summary

```
main-product.liquid
│
├── renders product-media-gallery.liquid
│     └── outputs data-variant-associated-urls JSON blob
│           └── read by variant-media-gallery.js → hides/shows slides & thumbnails
│
├── renders decal-calculator-trigger (the link)
│
└── renders decal-calculator-modal
      └── renders decal-calculator (the full UI + JS)
```

**Modal open/close flow:**
1. Customer clicks the trigger link (`#open-decal-calc`)
2. `decal-calculator-modal.liquid` JS adds `.is-visible` to `#dc-modal`
3. `window.dcCalc.init()` has already run on `DOMContentLoaded` — the calculator is live immediately

**Spacing tier flow:**
1. Customer clicks a tier card (Starter / Enhanced / Optimal)
2. `window.dcSelectTier(key)` updates `dcCalc.state.activeTier`
3. `calculate()` reads `dcCalc.tiers[activeTier].spX / spY` and rerenders

**Variant gallery filter flow:**
1. Customer selects a variant → Dawn updates the hidden `input[name="id"]`
2. `variant-media-gallery.js` detects the `change` event
3. Reads the `data-variant-associated-urls` JSON, gets the URL list for that variant
4. Shows slides/thumbnails whose `<img src>` matches, hides the rest

---

## Spacing Tiers Reference

| Tier | Horizontal gap | Vertical gap | Notes |
|---|---|---|---|
| Starter | 12" | 12" | Best aesthetics, limited bird deterrence |
| Enhanced | 6" | 6" | Balanced |
| Optimal ★ | 2" | 4" | Meets American Bird Conservancy guidelines |

Default selection is **Optimal**.

---

## Troubleshooting

**Calculator modal doesn't open**
- Check browser console for JS errors
- Confirm `decal-calculator-trigger` renders an element with `id="open-decal-calc"`
- Confirm `decal-calculator-modal` renders an element with `id="dc-modal"` and `id="close-decal-calc"`

**Gallery doesn't filter on variant change**
- Open browser console and look for `=== Variant Media Gallery Init ===` on page load
- Confirm `variant-media-gallery.js` is loading (check Network tab)
- Confirm `data-variant-associated-urls` JSON is present in page source (View Source → search for it)
- Confirm `custom.associated_media` is populated on the variant in the Shopify admin

**Decal count shows 0**
- Check that `custom.average_size` and `custom.decal_count` are set on the product
- The calculator defaults to `1.25in` size and `1` per envelope if metafields are missing — verify the values are saved, not just defined

**SVG visualizer shows a blank shape**
- `silhouette_path` metafield may be empty — set it, or set `decal_shape` to `diamond`, `circle`, or `square` as a fallback

---

## Notes for the Receiving Developer

- All calculator JS is namespaced under `window.dcCalc` to avoid conflicts
- Global onclick handlers are explicitly attached to `window` (`window.dcToggleMargin`, `window.dcSelectTier`) for the same reason
- The `setupModal()` function inside `decal-calculator.liquid` is intentionally absent — modal wiring lives entirely in `decal-calculator-modal.liquid`
- `variant-media-gallery.js` is a self-contained IIFE — it does not depend on any other custom JS
- Do not rename snippet files — the `{% render %}` calls in `main-product.liquid` reference them by exact name
