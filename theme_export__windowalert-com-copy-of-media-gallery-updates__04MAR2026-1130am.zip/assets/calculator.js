function calculateCoverage() {
    console.log("Calculator script running...");

    var windowWidth = parseFloat(document.getElementById("window-width").value);
    var windowHeight = parseFloat(document.getElementById("window-height").value);

    var decalWidth = 3.5;  // ✅ Updated decal size to 3.5 inches
    var decalHeight = 3.5;  
    var edgeSpacing = 6;  // inches
    var decalsPerPack = 4;  // 4 decals per pack

    // Get selected spacing value from radio buttons
    var spacingOptions = document.getElementsByName("spacing-option");
    var selectedSpacing;
    var densityFactor;

    for (var i = 0; i < spacingOptions.length; i++) {
        if (spacingOptions[i].checked) {
            selectedSpacing = parseFloat(spacingOptions[i].value);
            break;
        }
    }

    console.log("Selected Spacing:", selectedSpacing);

    if (isNaN(windowWidth) || isNaN(windowHeight) || windowWidth <= 0 || windowHeight <= 0) {
        document.getElementById("coverage-result").innerHTML = "Please enter valid window dimensions.";
        return;
    }

    // Adjust window dimensions by subtracting edge spacing
    var adjustedWindowWidth = windowWidth - 2 * edgeSpacing;
    var adjustedWindowHeight = windowHeight - 2 * edgeSpacing;

    console.log("Adjusted Width:", adjustedWindowWidth, "Adjusted Height:", adjustedWindowHeight);

    if (adjustedWindowWidth <= 0 || adjustedWindowHeight <= 0) {
        document.getElementById("coverage-result").innerHTML = "The window is too small for decals with the given spacing.";
        return;
    }

    // Define new density factors for 3.5" decals
    if (selectedSpacing === 20) {
        densityFactor = 1.0;  // ✅ "Good" - 1.2 decals per sq. ft.
    } else if (selectedSpacing === 10) {
        densityFactor = 1.4;  // ✅ "Better" - 1.8 decals per sq. ft.
    } else {
        densityFactor = 2.0;  // ✅ "Best" - 2.5 decals per sq. ft.
    }

    console.log("Density Factor:", densityFactor);

    // Calculate window area in square feet
    var windowArea = (adjustedWindowWidth / 12) * (adjustedWindowHeight / 12);

    // ✅ STEP 1: Determine the minimum required decals based on density
    var minDecalsRequired = Math.ceil(windowArea * densityFactor);  // ✅ Adjusted density factor here

    console.log("Minimum Decals Required (Density Override):", minDecalsRequired);

    // ✅ STEP 2: Compute rows and columns based on the minimum required decals
    var totalDecalsNeeded = Math.max(minDecalsRequired, 1); // ✅ Ensure at least 1 decal is placed
    var decalsPerRow = Math.ceil(Math.sqrt(totalDecalsNeeded * (adjustedWindowWidth / adjustedWindowHeight)));
    var decalsPerColumn = Math.ceil(totalDecalsNeeded / decalsPerRow);

    console.log("Decals Per Row (Adjusted):", decalsPerRow, "Decals Per Column (Adjusted):", decalsPerColumn);

    // ✅ STEP 3: Ensure decals fit within window space
    var finalSpacingX = Math.max((adjustedWindowWidth - (decalsPerRow * decalWidth)) / (decalsPerRow - 1), selectedSpacing);
    var finalSpacingY = Math.max((adjustedWindowHeight - (decalsPerColumn * decalHeight)) / (decalsPerColumn - 1), selectedSpacing);

    console.log("Final Adjusted Spacing X:", finalSpacingX, "Final Adjusted Spacing Y:", finalSpacingY);

    // ✅ STEP 4: Recalculate final total decals
    totalDecalsNeeded = decalsPerRow * decalsPerColumn;

    console.log("Final Total Decals Needed:", totalDecalsNeeded);

    // ✅ STEP 5: Determine how many packs are required
    var packsNeeded = Math.ceil(totalDecalsNeeded / decalsPerPack);

    console.log("Packs Needed:", packsNeeded);

    // ✅ STEP 6: Update result in the DOM
    document.getElementById("coverage-result").innerHTML =
        "You will need approximately <strong>" + totalDecalsNeeded + "</strong> decals, which requires <strong>" + packsNeeded + "</strong> packs of decals to cover this window at the selected spacing.";
}

// Ensure function is globally accessible
window.calculateCoverage = calculateCoverage;
console.log("Calculator JS Loaded!");
